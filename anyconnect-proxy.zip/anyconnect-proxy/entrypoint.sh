#!/bin/sh

# Check if required environment variables are set
if [ -z "$OPENCONNECT_USER" ] || [ -z "$OPENCONNECT_PASSWORD" ] || [ -z "$OPENCONNECT_URL" ]; then
    echo "Required environment variables are not set. Exiting."
    exit 1
fi

# Start OpenConnect in the background with appropriate options
echo "Connecting to VPN..."

if [ -n "$OPENCONNECT_AUTH_GROUP" ] && [ -n "$OPENCONNECT_SERVER_CERT" ]; then
    echo -n "$OPENCONNECT_PASSWORD" | openconnect -b "$OPENCONNECT_URL" --user="$OPENCONNECT_USER" --authgroup="$OPENCONNECT_AUTH_GROUP" --servercert="$OPENCONNECT_SERVER_CERT" --passwd-on-stdin
elif [ -n "$OPENCONNECT_AUTH_GROUP" ]; then
    echo -n "$OPENCONNECT_PASSWORD" | openconnect -b "$OPENCONNECT_URL" --user="$OPENCONNECT_USER" --authgroup="$OPENCONNECT_AUTH_GROUP" --passwd-on-stdin
elif [ -n "$OPENCONNECT_SERVER_CERT" ]; then
    echo -n "$OPENCONNECT_PASSWORD" | openconnect -b "$OPENCONNECT_URL" --user="$OPENCONNECT_USER" --servercert="$OPENCONNECT_SERVER_CERT" --passwd-on-stdin
else
    echo -n "$OPENCONNECT_PASSWORD" | openconnect -b "$OPENCONNECT_URL" --user="$OPENCONNECT_USER" --passwd-on-stdin
fi

# Start TinyProxy if both user and password are provided

sed "s/^Port .*$/Port 8888/" -i /etc/tinyproxy.conf

if [ -n "$TINYPROXY_USER" ] && [ -n "$TINYPROXY_PASS" ]; then
    echo "Configuring TinyProxy..."
    sed -i "s/^Allow /BasicAuth $TINYPROXY_USER $TINYPROXY_PASS\nAllow /" /etc/tinyproxy.conf

    echo "Starting TinyProxy..."
    tinyproxy -d -c /etc/tinyproxy.conf
else
    echo "Starting TinyProxy without authentication..."
    tinyproxy -d -c /etc/tinyproxy.conf
fi

# Keep the script running to prevent the container from exiting
tail -f /dev/null
